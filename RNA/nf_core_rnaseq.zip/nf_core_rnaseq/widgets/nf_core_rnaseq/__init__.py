import sysconfig

# Category metadata.

# Category icon show in the menu
ICON = "icon/user.png"

# Background color for category background in menu
# and widget icon background in workflow.
BACKGROUND = "light-blue"
